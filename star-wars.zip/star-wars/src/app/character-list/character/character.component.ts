import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICharacter } from '../../interfaces/ICharacter';
import { IMovie } from '../../interfaces/IMovie';

@Component({
  selector: 'app-character',
  templateUrl: './character.component.html',
  styleUrls: ['./character.component.css']
})
export class CharacterComponent implements OnInit {
  @Input() character: ICharacter = null;
  @Input() movies: IMovie[] = [];

  constructor() { }

  ngOnInit() {
  }
}
