import { StarwarsService } from '../services/starwars.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ICharacter } from '../interfaces/ICharacter';
import { Subscription } from 'rxjs';
import { IMovie } from '../interfaces/IMovie';

@Component({
  selector: 'app-character-list',
  templateUrl: './character-list.component.html',
  styleUrls: ['./character-list.component.css']
})
export class CharacterListComponent implements OnInit, OnDestroy {
  selectedCharacter: ICharacter = { name: 'noname', url: 'nourl' };
  selectedCharacterMovies: IMovie[] = [];
  characterListSubscription: Subscription;
  moviesUrlsListSubscription: Subscription;
  characterMoviesSubscription: Subscription;

  constructor(private starwarsService: StarwarsService) { }

  ngOnInit() {
    this.getCharacterList();
  }

  ngOnDestroy() {
    this.characterListSubscription.unsubscribe();
    this.moviesUrlsListSubscription.unsubscribe();
    this.characterMoviesSubscription.unsubscribe();
  }

  getCharacterList(): void {
    this.characterListSubscription = this.starwarsService.getCharacters().subscribe(
      (data) => {
        this.starwarsService.characters = data['characters'];
      },
      (err) => {
        alert('Error occured while getting list of characters');
      }
    );
  }


  // returns the list of movies (information included) for a specified character
  getCharacterMovies(character: ICharacter): IMovie[] {
    if (this.isCharacterSelected(character)) {
      return this.selectedCharacterMovies;
    } else {
      return [];
    }
  }

  isCharacterSelected(character: ICharacter): boolean {
    return character.name === this.selectedCharacter.name;
  }

  /* first checks if the same character was already selected which means we don't have to proceed to the rest of the method.
  * if a different character was selected then we first use the url of the character we got from the initial character list json file in order 
  * to get the list of movies urls and then we use that to get the character's movies info. 
  * Error Handling: if a rest call fails and an error message comes back from the server then we show an alert message with it, otherwise
  * we just alert with a default message.
  */
  selectCharacter(character: ICharacter): void {
    if (character.name === this.selectedCharacter.name) {
      return;
    }
    this.selectedCharacter = character;
    this.selectedCharacterMovies = [];

    // now get the movies urls list of the selected character
    this.moviesUrlsListSubscription = this.starwarsService.getCharacterInfo(character).subscribe(
      (data) => {
        const moviesUrls = data['films'];
        // now that we have all of the movies urls, we can make a call to get the movies information for the character selected
        this.characterMoviesSubscription = this.starwarsService.getMoviesInfo(moviesUrls).subscribe(
          (movies) => {
            this.selectedCharacterMovies = movies;

            if (!this.selectedCharacterMovies.length) {
              alert('No movies exist for the selected character: ' + character.name);
            }
          },
          (err) => {
            console.error('Error while getting movies info.');
          }
        );
      },
      (err) => {
        if (err.detail) {
          alert('Error: ' + err.detail);
        } else {
          alert('Error occured while getting character information about: ' + character.name);
        }

      }
    );
  }
}
