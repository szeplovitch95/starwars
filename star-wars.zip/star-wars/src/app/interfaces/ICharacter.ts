import { IMovie } from './IMovie';

export interface ICharacter {
    name: string;
    url: string;
    movies?: IMovie[];
}
