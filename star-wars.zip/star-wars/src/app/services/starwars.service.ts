import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';
import { ICharacter } from '../interfaces/ICharacter';

@Injectable({
    providedIn: 'root'
})
export class StarwarsService {
    jsonCharactersFilePath = 'assets/characters.json';
    restapiverb = 'users';
    characters = [];

    constructor(private http: HttpClient) { }

    getCharacters(): Observable<ICharacter[]> {
        return this.http.get<ICharacter[]>(this.jsonCharactersFilePath);
    }

    getCharacterInfo(character: ICharacter): Observable<String[]> {
        return this.http.get<String[]>(character.url);
    }

    getMoviesInfo(movies: string[]): Observable<any> {
        const moviesObservables = [];

        // creates an array of observables from the movies urls we recieved
        movies.forEach(movie => {
            moviesObservables.push(
                this.http.get(movie)
            );
        });

        // makes an async call to get all of the movies info and only returns when all are finished
        return forkJoin(moviesObservables);
    }
}
